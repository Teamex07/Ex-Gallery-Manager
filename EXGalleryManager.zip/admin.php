<?php
//Write your password here
$admin = "Your Password";

/*

Don't change any other word here.
Just change (Your Password) to (New Password).
Don't edit ($admin = "";) otherwise this code does not work.

	....................
	.                  .
	.     TEAM EX      .
	.                  .
	....................

..........Developer...........
.                            .
.    *** Samiul Alim ***     .
.  samiulalim1230@gmail.com  .
.    fb : samiul.alim.1230   .
.     tg : samiulalim1230    .
.                            .
..............................

    Copyright © 2022
       Team Ex

*/
?>
